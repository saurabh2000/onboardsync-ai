"use client"
import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  ArrowRight, 
  Sparkles, 
  Bot, 
  Zap, 
  Play,
  Workflow, 
  BarChart3, 
  Check, 
  Star, 
  Crown,
  TrendingUp,
  Users,
  Clock,
  Heart,
  Github,
  Twitter,
  Linkedin
} from 'lucide-react';

const LandingPage = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [billingCycle, setBillingCycle] = useState('monthly');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Navigation component
  const Navigation = () => (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/90 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className={`ml-2 text-xl font-bold ${isScrolled ? 'text-gray-900' : 'text-white'}`}>
                OnBoardSync.AI
              </span>
            </div>
          </div>

          {/* Desktop navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {['Features', 'Pricing', 'Demo', 'Docs'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className={`px-3 py-2 text-sm font-medium transition-colors ${
                    isScrolled 
                      ? 'text-gray-700 hover:text-purple-600' 
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {item}
                </a>
              ))}
            </div>
          </div>

          {/* CTA buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <button className={`px-4 py-2 text-sm font-medium transition-colors ${
              isScrolled 
                ? 'text-gray-700 hover:text-purple-600' 
                : 'text-gray-300 hover:text-white'
            }`}>
              Sign In
            </button>
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 transform hover:scale-105">
              Start Free Trial
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`p-2 rounded-md ${isScrolled ? 'text-gray-700' : 'text-white'}`}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {['Features', 'Pricing', 'Demo', 'Docs'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-purple-600"
                onClick={() => setIsMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <div className="pt-4 pb-2 border-t border-gray-200">
              <button className="block w-full text-left px-3 py-2 text-base font-medium text-gray-700 hover:text-purple-600">
                Sign In
              </button>
              <button className="block w-full mt-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                Start Free Trial
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );

  // Hero Section
  const HeroSection = () => (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>
      
      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="inline-flex items-center px-4 py-2 mb-8 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-white text-sm font-medium animate-fade-in">
          <Sparkles className="w-4 h-4 mr-2 text-yellow-400" />
          AI-Powered Customer Onboarding Platform
          <ArrowRight className="w-4 h-4 ml-2" />
        </div>

        {/* Main headline */}
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in-up" style={{animationDelay: '0.2s'}}>
          Transform Every
          <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent"> Customer Journey</span>
        </h1>

        {/* Subheadline */}
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed animate-fade-in-up" style={{animationDelay: '0.4s'}}>
          Create intelligent, adaptive onboarding flows that understand your customers and guide them to success with AI-powered conversations and visual flow building.
        </p>

        {/* Key benefits */}
        <div className="flex flex-wrap justify-center gap-6 mb-12 animate-fade-in-up" style={{animationDelay: '0.6s'}}>
          <div className="flex items-center text-gray-300">
            <Bot className="w-5 h-5 mr-2 text-purple-400" />
            <span>AI-Powered Conversations</span>
          </div>
          <div className="flex items-center text-gray-300">
            <Zap className="w-5 h-5 mr-2 text-cyan-400" />
            <span>Visual Flow Builder</span>
          </div>
          <div className="flex items-center text-gray-300">
            <Sparkles className="w-5 h-5 mr-2 text-pink-400" />
            <span>Real-time Analytics</span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up" style={{animationDelay: '0.8s'}}>
          <button className="group bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-purple-500/25">
            Start Free Trial
            <ArrowRight className="inline-block w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </button>
          
          <button className="group bg-white/10 backdrop-blur-sm border border-white/20 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 hover:bg-white/20">
            <Play className="inline-block w-5 h-5 mr-2" />
            Watch Demo
          </button>
        </div>

        {/* Social proof */}
        <div className="animate-fade-in-up" style={{animationDelay: '1s'}}>
          <p className="text-gray-400 text-sm mb-6">Trusted by innovative companies worldwide</p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {['TechCorp', 'InnovateLabs', 'FutureScale', 'CloudVenture', 'DataFlow'].map((company) => (
              <div key={company} className="text-gray-400 font-semibold text-lg hover:text-white transition-colors">
                {company}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Floating elements */}
      <div className="absolute top-20 left-10 w-16 h-16 bg-purple-500/20 rounded-full animate-bounce" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-20 right-10 w-12 h-12 bg-cyan-500/20 rounded-full animate-bounce" style={{animationDelay: '2s'}}></div>
      <div className="absolute top-1/2 right-20 w-8 h-8 bg-pink-500/20 rounded-full animate-bounce" style={{animationDelay: '3s'}}></div>
    </div>
  );

  // Features Section
  const FeaturesSection = () => (
    <section id="features" className="py-24 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-4 py-2 mb-6 bg-purple-100 rounded-full text-purple-700 text-sm font-medium">
            <Sparkles className="w-4 h-4 mr-2" />
            Powerful Features
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Everything you need to
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"> onboard customers</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Build, deploy, and optimize customer onboarding experiences that convert visitors into engaged users.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {[
            {
              icon: <Bot className="w-8 h-8" />,
              title: "AI-Powered Conversations",
              description: "Intelligent chat system that understands context, learns from interactions, and provides personalized guidance to each customer."
            },
            {
              icon: <Workflow className="w-8 h-8" />,
              title: "Visual Flow Builder",
              description: "Drag-and-drop interface to create complex onboarding journeys without code. Design branching paths and conditional logic effortlessly."
            },
            {
              icon: <BarChart3 className="w-8 h-8" />,
              title: "Real-time Analytics",
              description: "Track conversion rates, identify drop-off points, and optimize your onboarding flows with actionable insights and detailed reports."
            }
          ].map((feature, index) => (
            <div key={index} className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border border-gray-100">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-r from-purple-500 to-pink-500 text-white mb-6 group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>

        {/* Stats section */}
        <div className="mt-20 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-600 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold mb-4">
                Proven Results That Drive Growth
              </h3>
              <p className="text-xl opacity-90">
                See the impact OnBoardSync.AI has on businesses like yours
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div className="group">
                <div className="flex items-center justify-center mb-4">
                  <TrendingUp className="w-8 h-8 mr-2" />
                  <span className="text-4xl md:text-5xl font-bold">3.2x</span>
                </div>
                <p className="text-lg opacity-90">Average increase in conversion rates</p>
              </div>
              
              <div className="group">
                <div className="flex items-center justify-center mb-4">
                  <Clock className="w-8 h-8 mr-2" />
                  <span className="text-4xl md:text-5xl font-bold">67%</span>
                </div>
                <p className="text-lg opacity-90">Reduction in onboarding time</p>
              </div>
              
              <div className="group">
                <div className="flex items-center justify-center mb-4">
                  <Users className="w-8 h-8 mr-2" />
                  <span className="text-4xl md:text-5xl font-bold">250k+</span>
                </div>
                <p className="text-lg opacity-90">Customers onboarded daily</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );

  // Pricing Section
  const PricingSection = () => (
    <section id="pricing" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 mb-6 bg-purple-100 rounded-full text-purple-700 text-sm font-medium">
            <Star className="w-4 h-4 mr-2" />
            Simple, Transparent Pricing
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Choose the perfect plan for
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"> your business</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Start free and scale as you grow. All plans include our core features with no hidden fees.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {[
            {
              name: "Starter",
              price: "Free",
              popular: false,
              features: ["3 onboarding flows", "100 conversations/month", "Basic analytics", "Email support", "Standard templates", "API access"]
            },
            {
              name: "Professional",
              price: "$49",
              popular: true,
              features: ["Unlimited flows", "5,000 conversations/month", "Advanced analytics", "Priority support", "Custom branding", "A/B testing", "Webhook integrations", "Team collaboration"]
            },
            {
              name: "Enterprise",
              price: "Custom",
              popular: false,
              features: ["Everything in Pro", "Unlimited conversations", "Custom AI training", "SSO & advanced security", "Dedicated account manager", "Custom integrations", "SLA guarantee"]
            }
          ].map((plan, index) => (
            <div key={index} className={`bg-white rounded-3xl shadow-xl p-8 ${plan.popular ? 'ring-4 ring-purple-500/20 border-2 border-purple-500' : 'border-2 border-gray-200'} transition-all duration-300 hover:shadow-2xl hover:-translate-y-2`}>
              {plan.popular && (
                <div className="text-center mb-4">
                  <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${plan.popular ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
                  {index === 0 ? <Users className="w-6 h-6" /> : index === 1 ? <Zap className="w-6 h-6" /> : <Crown className="w-6 h-6" />}
                </div>
                <div className="ml-4">
                  <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                </div>
              </div>
              <div className="mb-8">
                <div className="flex items-baseline">
                  <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                  {plan.price !== "Free" && plan.price !== "Custom" && (
                    <span className="text-gray-600 ml-2">/month</span>
                  )}
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              <button className={`w-full py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl ${
                plan.popular 
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white' 
                  : 'bg-gray-900 hover:bg-gray-800 text-white'
              }`}>
                {plan.name === "Enterprise" ? "Contact Sales" : "Get Started"}
                {plan.name !== "Enterprise" && <ArrowRight className="inline-block w-5 h-5 ml-2" />}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  // Footer
  const Footer = () => (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className="ml-2 text-xl font-bold">OnBoardSync.AI</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Transform your customer onboarding with AI-powered conversations and intelligent flow building.
            </p>
            <div className="flex space-x-4">
              <Twitter className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Linkedin className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Github className="w-5 h-5 text-gray-400 hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Product</h3>
            <ul className="space-y-2">
              {['Features', 'Pricing', 'Demo', 'API Docs', 'Integrations'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              {['About', 'Blog', 'Careers', 'Privacy', 'Terms'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 OnBoardSync.AI. All rights reserved.
          </p>
          <div className="flex items-center mt-4 md:mt-0">
            <span className="text-gray-400 text-sm mr-2">Made with</span>
            <Heart className="w-4 h-4 text-red-500" />
            <span className="text-gray-400 text-sm ml-2">for better onboarding</span>
          </div>
        </div>
      </div>
    </footer>
  );

  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <PricingSection />
      <Footer />
    </div>
  );
};

export default LandingPage;