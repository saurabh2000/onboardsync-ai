import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  metadataBase: new URL('https://onboardsync.ai'),
  title: 'OnBoardSync.AI - Transform Every Customer Journey',
  description: 'Create intelligent, adaptive onboarding flows that understand your customers and guide them to success with AI-powered conversations and visual flow building.',
  keywords: [
    'customer onboarding',
    'AI chatbot', 
    'SaaS onboarding',
    'user journey',
    'conversion optimization',
    'flow builder',
    'onboarding automation',
    'customer success'
  ],
  authors: [{ name: 'OnBoardSync.AI Team' }],
  creator: 'OnBoardSync.AI',
  publisher: 'OnBoardSync.AI',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://onboardsync.ai',
    siteName: 'OnBoardSync.AI',
    title: 'OnBoardSync.AI - Transform Every Customer Journey',
    description: 'Create intelligent, adaptive onboarding flows that understand your customers and guide them to success with AI-powered conversations.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'OnBoardSync.AI - AI-Powered Customer Onboarding Platform',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@onboardsyncai',
    creator: '@onboardsyncai',
    title: 'OnBoardSync.AI - Transform Every Customer Journey',
    description: 'Create intelligent, adaptive onboarding flows that understand your customers and guide them to success with AI-powered conversations.',
    images: ['/og-image.png'],
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#7c3aed',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}