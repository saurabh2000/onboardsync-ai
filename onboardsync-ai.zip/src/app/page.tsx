import LandingPage from '@/components/marketing/landing-page'

export default function Home() {
  return <LandingPage />
}